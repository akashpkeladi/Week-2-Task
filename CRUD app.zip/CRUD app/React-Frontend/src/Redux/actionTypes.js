export const USER_STORED = "userStored";
export const USER_UPDATED= "userUpdated";
export const SHOW_STATUS = "showStatus";